/**********************************************************************/
/* InstallAzure.SQL                                                   */
/*                                                                    */
/* Preinstall for installing ASP.NET schemas on SQL Azure - Creates   */
/* aspnetdb.									                      */
/*                                                                    */
/*
** Copyright Microsoft, Inc. 2002
** All Rights Reserved.
*/
/**********************************************************************/

CREATE DATABASE [aspnetdb]
GO